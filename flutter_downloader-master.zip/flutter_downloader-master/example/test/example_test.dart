import 'package:flutter_test/flutter_test.dart';

void main() {
  test('example test', () {
    expect(2 + 2, 4);
  });
}
