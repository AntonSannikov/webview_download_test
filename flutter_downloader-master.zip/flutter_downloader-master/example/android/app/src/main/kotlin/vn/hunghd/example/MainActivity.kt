package vn.hunghd.example;

import io.flutter.embedding.android.FlutterActivity;

class MainActivity : FlutterActivity()
